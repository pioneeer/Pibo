﻿using UnityEngine;
using System.Collections;


public class Gallery : MonoBehaviour {
	private Global_Var Glo;
	public UnityEngine.UI.Image Img_Preview;
	public string[] Receive_Str_Split;
	//
	//곰 세마리 양손
	//string Default_STR = "144,146,146,144,144,164,186,186,164,144,186,186,164,186,186,164,/,194,214,284,214,194,214,284,214,194,214,284,214,/,144,144,144,284,184,184,164,144,184,184,184,284,/,194,214,284,214,194,214,284,214,184,224,284,224,/,end";

	//곰 세마리 한손
	//string Default_STR = "144,146,146,144,144,,164,186,186,164,144,,186,186,164,186,186,164,,144,144,142,/,184,184,164,144,,184,184,182,,184,184,164,144,,184,184,182,/,184,184,164,144,,186,186,186,196,182,,214,184,214,184,,164,154,142,,/,end";

	//자전거
	//string Default_STR = "166,186,184,,166,186,184,,196,196,196,196,,193,,/,,186,186,186,186,,176,176,176,176,,166,166,166,166,,163,/,166,186,186,186,,166,186,184,,195,186,166,166,,183,/,176,176,176,176,,166,166,166,166,,156,156,186,186,,143,/,end";

	//달
	string Default_STR = "6,174,194,,216,216,194,,206,196,186,176,,186,186,144,,/,6,176,176,196,196,,216,216,194,,186,206,196,186,,176,176,174,24,/,end";

	void Start () {
		Glo = GameObject.Find ("Global").GetComponent <Global_Var>();
	}

	public void BtnRestart() {

		Glo.Note_Info_Init();

		if (Application.platform == RuntimePlatform.Android) 
		{
			AndroidJavaClass ajc = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
			AndroidJavaObject ajo = new AndroidJavaObject("com.jun.gallery.UnityBinder");

			ajo.CallStatic("OpenGallery", ajc.GetStatic<AndroidJavaObject>("currentActivity"));

			// Android에서 onMsg 함수로 String수신받음.
		}
		else
		{
			Glo.Path_Original_Img = Glo.Path_Original + "/Assets/Resources/test.jpg";
			Img_Preview.SendMessage("Image_Load");

			// Default
			onMsg(Default_STR);
		}
	}

	public void OnPhotoPick(string filePath)
	{
		Debug.Log(filePath);
		Glo.Path_Original_Img = filePath;
		Img_Preview.SendMessage ("Image_Load");
	}

	public void onMsg(string msg){
		Glo.Note_Info_Init ();

		int i=0;
		Receive_Str_Split = msg.Split(',');
		//Receive_Str_Split = Default_STR.Split(',');
		
		while ( Receive_Str_Split[i] != "end" )
		{
			if(Receive_Str_Split[i] != "") Note_Msg( Receive_Str_Split[i++] );
			else i++;
		}
	}

	public void Note_Msg(string msg){
		//Debug.LogError( msg );
		Glo.Note_Info[Glo.Note_Info_Cnt++] = msg;
	}
}
