#pragma strict

var Glo : Global_Var;
var Input_Name : UnityEngine.UI.InputField;
var Btn_Sucess : UI.Button;
var Text_Error : UI.Text;
var Togle_Double_Hand : UI.Toggle;

private var temp : String;

function Start () {
	Glo = GameObject.Find("Global").GetComponent("Global_Var");
}

function BtnRestart () {
	
	if( Input_Name.text == "")
	{
		Text_Error.text = "악보의 이름을 입력하세요.";
		Text_Error.SendMessage("Error_Occured");
	}
	else 
	{
		if( !System.IO.File.Exists(Glo.Path_Directory + "/" + Input_Name.text + ".txt") && System.IO.File.Exists(Glo.Path_Original_Img) )
		{
			Make_Note (Glo.Path_Directory, Input_Name.text);
			Copy_Img(Glo.Path_Directory, Input_Name.text);
			
			Glo.Note[Glo.Note_Total++] = Input_Name.text;
			Index_Add(Glo.Path_Index, Glo.Path_Index_Copy, Input_Name.text);
			
			Glo.Note_Now = Glo.Note_Total;
			
			Glo.Note_Info_Init();
			
			Application.LoadLevel("01_Music_List");
		}
		else if( System.IO.File.Exists(Glo.Path_Directory + "/" + Input_Name.text + ".txt") )
		{
			Text_Error.text = "동일한 이름의 악보 존재";
			Text_Error.SendMessage("Error_Occured");
		}
		else if ( !System.IO.File.Exists(Glo.Path_Original_Img) )
		{
			Text_Error.text = "악보를 지정해 주세요";
			Text_Error.SendMessage("Error_Occured");
		}
		else
		{
			Text_Error.text = "Error.";
			Text_Error.SendMessage("Error_Occured");
		}
	}
}

function Index_Add (Original_File : String, Copy_File : String, String_to_Write : String) 
{ 
	var sr : System.IO.StreamReader;
	var sw : System.IO.StreamWriter;
	
	var input : String;
	input = "";
	
	sr = new System.IO.File.OpenText (Copy_File);
	sw = new System.IO.StreamWriter (Original_File);
	
	sw.Flush();
	while (true)
	{ 
		input = sr.ReadLine(); 
		if (input == null)	 break; 
		
		sw.WriteLine(input);
	}
	sw.WriteLine(String_to_Write);
	
	sr.Close();
	sw.Close();
	
	sr = new System.IO.File.OpenText (Original_File);
	sw = new System.IO.StreamWriter (Copy_File);
	input = "";
	
	sw.Flush();
	while (true)
	{ 
		input = sr.ReadLine(); 
		if (input == null)	 break; 
		
		sw.WriteLine(input);
	}
	
	sr.Close();
	sw.Close();
}

function Make_Note (Directory : String, Note_Name : String)
{
	var sw : System.IO.StreamWriter;
	var Str : String;
	Str = "";
	
	System.IO.File.Create (Directory + "/" + Note_Name + ".txt").Dispose();
	sw = new System.IO.StreamWriter (Directory + "/" + Note_Name + ".txt");
	sw.Flush();
	
	if(Togle_Double_Hand.isOn)	sw.WriteLine("Double_Hand");
	else						sw.WriteLine("Single_Hand");
	
	for (var i = 0; i< Glo.Note_Info_Cnt; i++)
	{
		sw.WriteLine(Glo.Note_Info[i]);
	}
	
	sw.Close();
}

function Copy_Img (Directory : String, Note_Name : String)
{
	var Double_Hand : int;
	
	System.IO.File.Copy (Glo.Path_Original_Img, Directory + "/" + Note_Name + ".jpg");
}