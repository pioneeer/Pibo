﻿#pragma strict

function Start () {
	this.transform.position.y = 1000;
}

function BtnRestart () {
 	Application.LoadLevel("01_Music_List"); 
}