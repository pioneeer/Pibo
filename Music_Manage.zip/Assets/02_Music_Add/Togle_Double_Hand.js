﻿#pragma strict

var Togle : UI.Toggle;
var Glo : Global_Var;

function Start () {

}

function Update () {

}