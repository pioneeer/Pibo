﻿#pragma strict

var Text_Directory : UI.Text;
var Glo : Global_Var;

function Start () {
	Glo = GameObject.Find("Global").GetComponent("Global_Var");
	Text_Directory.text = "Path : " + Glo.Path_Directory;
	Text_Directory.text += "\nOriginal : " + Glo.Path_Original;
}