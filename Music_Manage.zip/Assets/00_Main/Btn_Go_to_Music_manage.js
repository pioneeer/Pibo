﻿#pragma strict
 
function BtnRestart () {
 
    Application.LoadLevel("01_Music_List");
 
}