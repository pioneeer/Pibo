#pragma strict

var Glo : Global_Var;

function Start () {
	Glo = GameObject.Find("Global").GetComponent("Global_Var");
	Glo.Note_Now = 1;
	
	Find_Path();
	
	if( !System.IO.Directory.Exists(Glo.Path_Directory) )	System.IO.Directory.CreateDirectory (Glo.Path_Directory);
	if( !System.IO.File.Exists(Glo.Path_Index) )			System.IO.File.Create (Glo.Path_Index);
	if( !System.IO.File.Exists(Glo.Path_Index_Copy) )		System.IO.File.Create (Glo.Path_Index_Copy);
	
	Index_Copy(Glo.Path_Index, Glo.Path_Index_Copy);
	Make_Note_List(Glo.Path_Index);
}

function Update () {

}

function Find_Path ()
{	
	if (Application.platform == RuntimePlatform.IPhonePlayer)
	{
		Glo.Path_Original = Application.dataPath.Substring( 0, Application.dataPath.Length - 5 );
		Glo.Path_Original = Glo.Path_Original.Substring( 0, Glo.Path_Original.LastIndexOf( '/' ) );
	}

	else if(Application.platform == RuntimePlatform.Android)
	{
		Glo.Path_Original = Application.persistentDataPath; 
		Glo.Path_Original = Glo.Path_Original.Substring(0, Glo.Path_Original.LastIndexOf( '/' ) ); 
		Glo.Path_Directory = "/storage/sdcard0/Jun_Data/Note_Info";
	} 

	else 
	{
		Glo.Path_Original = Application.dataPath; 
		Glo.Path_Original = Glo.Path_Original.Substring(0, Glo.Path_Original.LastIndexOf( '/' ) );
		Glo.Path_Directory = "C:/Users/JINHONG AHN/Desktop/Fianl/Note_Info";
		//Glo.Path_Directory = "C:/Users/Jun/Google 드라이브/Cloud/SSM/Project/[15-1]피보증/Unity3D_Project/Note_Info";
	}
	
	Glo.Path_No_Img = Glo.Path_Original + "/Assets/Resources/NoImage.jpg";
	Glo.Path_Index = Glo.Path_Directory + "/index.txt";
	Glo.Path_Index_Copy = Glo.Path_Directory + "/index_copy.txt";
}

function Index_Copy (Original_File : String, Target_File : String)
{
	var sr : System.IO.StreamReader = new System.IO.File.OpenText (Original_File);
	var sw : System.IO.StreamWriter = new System.IO.StreamWriter (Target_File);
	
	var input : String;
	input = "";
	
	sw.Flush();
	
	while (true)
	{ 
		input = sr.ReadLine(); 
		if (input == null)	 break; 
		
		else sw.WriteLine(input);
	} 
	
	sr.Close();
	sw.Close();  
}

function Make_Note_List (Directory_Index : String)
{
	var sr : System.IO.StreamReader = new System.IO.File.OpenText (Directory_Index);
	var i : int;
	var input : String;
	
	i = 0;
	input = "";
	
	while(true)
	{
		input = sr.ReadLine(); 
		if (input == null)	 break; 
		
		else
		{
			Glo.Note[i++] = input;
		}
	}
	Glo.Note_Total = i;
	
	sr.Close();
}