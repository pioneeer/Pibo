﻿#pragma strict
 
function BtnRestart () {
 
    Application.LoadLevel("10_Option") ;
 
}