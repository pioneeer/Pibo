﻿#pragma strict

var Note_Total : int;
var Note_Now : int;
var Note : String[] = new String[99];

var Note_Info : String[] = new String[2000];
var Note_Info_Cnt : int;

var Path_Original : String;
var Path_Directory : String;
var Path_Index : String;
var Path_Index_Copy : String;
var Path_Original_Img : String;
var Path_No_Img : String;
var Path_Note_Now : String;
var Path_Now_Playing : String;

var Play_Time : float;
var Now_Playing : boolean;
var Play_End : boolean;

var Play_Speed_Base : float;
var Note_Speed_Base : float;
var Play_Speed_Mul : int;
var Note_Speed_Mul : int;
var Play_Speed_Mul_Default : int;
var Note_Speed_Mul_Default : int;

function Awake()
{
	DontDestroyOnLoad(this);
}

function Start () {
	Note_Total = 0;
	Note_Now = 0;
	Note_Info_Cnt = 0;
	
	Play_Speed_Base = 6.5;
	Note_Speed_Base = 10;
	Play_Speed_Mul_Default = 10;
	Note_Speed_Mul_Default = 10;
	Play_Speed_Mul = 10;
	Note_Speed_Mul = 10;
	
	Note_Info_Init();
}

function Update () {

}

function Note_Info_Init () {
	var i : int;
	
	if (Note_Info_Cnt == 0)	Note_Info_Cnt = 2000;
	
	for(i=0; i<Note_Info_Cnt; i++)	Note_Info[i] = "";
	Note_Info_Cnt = 0;
}