﻿#pragma strict

var Option : Option;

function Start () {
	Option = GameObject.Find("Option").GetComponent("Option");
}

function BtnRestart () {
	if (this.name == "Btn_Play_Up") {
		if(Option.Play_Speed_Mul_temp < 20) Option.Play_Speed_Mul_temp++;
	}
	else if (this.name == "Btn_Play_Down") {
		if(Option.Play_Speed_Mul_temp > 5) Option.Play_Speed_Mul_temp--;
	}
	else if (this.name == "Btn_Note_Up") {
		if(Option.Note_Speed_Mul_temp < 20) Option.Note_Speed_Mul_temp++;
	}
	else if (this.name == "Btn_Note_Down") {
		if(Option.Note_Speed_Mul_temp > 5) Option.Note_Speed_Mul_temp--;
	}
	
	Option.SendMessage("Refresh");
}