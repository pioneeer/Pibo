﻿#pragma strict

var Glo : Global_Var;
var Text_Play_Speed : UI.Text;
var Text_Note_Speed : UI.Text;

var Play_Speed_Mul_temp : int;
var Note_Speed_Mul_temp : int;

function Start () {
	Glo = GameObject.Find("Global").GetComponent("Global_Var");
	
	Play_Speed_Mul_temp = Glo.Play_Speed_Mul;
	Note_Speed_Mul_temp = Glo.Note_Speed_Mul;
	
	Refresh();
}

function Update () {

}

function Refresh () {
	Text_Play_Speed.text = "" + (Play_Speed_Mul_temp/10) + "." +(Play_Speed_Mul_temp%10);
	Text_Note_Speed.text = "" + (Note_Speed_Mul_temp/10) + "." +(Note_Speed_Mul_temp%10);
}