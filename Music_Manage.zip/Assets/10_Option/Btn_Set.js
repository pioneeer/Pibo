﻿#pragma strict

var Glo : Global_Var;
var Option : Option;

function BtnRestart () {
	Glo = GameObject.Find("Global").GetComponent("Global_Var");
	Glo.Play_Speed_Mul = Option.Play_Speed_Mul_temp;
	Glo.Note_Speed_Mul = Option.Note_Speed_Mul_temp;
	
	Application.LoadLevel("00_Main") ;
}