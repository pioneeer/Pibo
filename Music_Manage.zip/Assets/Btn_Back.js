﻿#pragma strict

function BtnRestart () {
 	if 		(Application.loadedLevelName == "01_Music_List")	Application.LoadLevel("00_Main"); 
 	else if (Application.loadedLevelName == "02_Music_Add")		Application.LoadLevel("01_Music_List"); 
 	else if (Application.loadedLevelName == "03_Music_Play")	Application.LoadLevel("01_Music_List");
 	else if (Application.loadedLevelName == "09_Gyro_Accel")	Application.LoadLevel("00_Main"); 
 	else if (Application.loadedLevelName == "10_Option")		Application.LoadLevel("00_Main"); 
}

function Update () {
	if(Input.GetKeyDown(KeyCode.Escape))
	{
		if 		(Application.loadedLevelName == "000_Intro")	 	Application.Quit();
		else if	(Application.loadedLevelName == "00_Main")		 	Application.Quit();
		else if (Application.loadedLevelName == "01_Music_List")	Application.LoadLevel("00_Main"); 
	 	else if (Application.loadedLevelName == "02_Music_Add")		Application.LoadLevel("01_Music_List"); 
	 	else if (Application.loadedLevelName == "03_Music_Play")	Application.LoadLevel("01_Music_List");
	 	else if (Application.loadedLevelName == "09_Gyro_Accel")	Application.LoadLevel("00_Main"); 
	 	return;
	}
}