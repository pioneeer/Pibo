﻿#pragma strict

private var Glo : Global_Var;

private var byteTexture : byte[];
var Max_Size : int;
var Img_Width : int;
var Img_Height : int;

var Img_texture : Texture2D = null; 
var Note_Now_Keep : int;

function Start () {
	Glo = GameObject.Find("Global").GetComponent("Global_Var");
	Note_Now_Keep = Glo.Note_Now;
	Glo.Path_Original_Img = "";
	Max_Size = 600;
	Image_Load();
}

function Update () {
	if 		(Application.loadedLevelName == "01_Music_List")
	{	
		if (Note_Now_Keep != Glo.Note_Now)		Image_Load();
		Note_Now_Keep = Glo.Note_Now;
	}
}

function Image_Load()
{	
	var Path_Img : String;
	Img_texture = null;
	
	if 		(Application.loadedLevelName == "01_Music_List")
	{
		if( Glo.Note_Total > 0)
		{
			Path_Img = Glo.Path_Directory + "/" + Glo.Note[Glo.Note_Now-1] + ".jpg";
			
			if( System.IO.File.Exists(Path_Img) )	byteTexture = System.IO.File.ReadAllBytes(Path_Img);
			
			if (byteTexture.Length > 0) 
			{
				Img_texture = new Texture2D(4, 4); 
				Img_texture.LoadImage(byteTexture);
			}
			else Img_texture = Resources.Load( "NoImage" , typeof(Texture2D) )as Texture2D;
		}
		else	Img_texture = Resources.Load( "NoImage" , typeof(Texture2D) )as Texture2D;
	}
	
	else if (Application.loadedLevelName == "02_Music_Add")
	{
		if( Glo.Path_Original_Img == "" )
		{
			Img_texture = Resources.Load( "NoImage" , typeof(Texture2D) )as Texture2D;
		}
		
		else 
		{
			if( System.IO.File.Exists(Glo.Path_Original_Img) )
			{
				byteTexture = System.IO.File.ReadAllBytes(Glo.Path_Original_Img);
				if (byteTexture.Length > 0) 
				{ 
					Img_texture = new Texture2D(4, 4);
					Img_texture.LoadImage(byteTexture); 
				}
			}
		}
	}
	
	Size_Check();
}

function Size_Check() {
	if(!Img_texture){
		Debug.LogError("Assign a Texture in the inspector.");
		return;
	}
	
	if(Img_texture.width > Img_texture.height)
	{
		if (Img_texture.width > Max_Size)
		{
			Img_Width = Max_Size;
			Img_Height = Img_texture.height * Max_Size / Img_texture.width;
		}
		else 
		{
			Img_Width = Img_texture.width * Max_Size / Img_texture.width;
			Img_Height = Img_texture.height  * Max_Size / Img_texture.width;
		}
	}
	
	else
	{
		if (Img_texture.height > Max_Size)
		{
			Img_Height = Max_Size;
			Img_Width = Img_texture.width * Max_Size / Img_texture.height;
		}
		else 
		{
			Img_Width = Img_texture.width * Max_Size / Img_texture.height;
			Img_Height = Img_texture.height * Max_Size / Img_texture.height;
		}
	}
}

function OnGUI() {	
	if(!Img_texture){
		Debug.LogError("Assign a Texture in the inspector.");
		return;
	}
	GUI.DrawTexture(Rect(940-(Img_Width/2),360-(Img_Height/2),Img_Width,Img_Height), Img_texture, ScaleMode.ScaleToFit, true, 0);	
}