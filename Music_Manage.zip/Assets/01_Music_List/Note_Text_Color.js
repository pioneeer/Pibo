﻿#pragma strict

var Glo : Global_Var;
var Curs : Cursor_Ctrl;

var Note_01 : UI.Text;
var Note_02 : UI.Text;
var Note_03 : UI.Text;
var Note_04 : UI.Text;

function Start () {	
	Glo = GameObject.Find("Global").GetComponent("Global_Var");
	Curs = GameObject.Find("Cursor_Ctrl").GetComponent("Cursor_Ctrl");
}

function Update () {
	if (Glo.Note_Total > 0)
	{
		if ( Curs.Cursor_pos == 0 || Curs.Cursor_pos == 1 )	Note_01.color = Color.black;
		else												Note_01.color = Color.grey;
		
		if ( Curs.Cursor_pos == 2 )	Note_02.color = Color.black;
		else						Note_02.color = Color.grey;
		
		if ( Curs.Cursor_pos == 3 )	Note_03.color = Color.black;
		else						Note_03.color = Color.grey;
		
		if ( Curs.Cursor_pos == 4 || Curs.Cursor_pos == 5 )	Note_04.color = Color.black;
		else												Note_04.color = Color.grey;
	}
	
	else
	{
		Note_01.color = Color.grey;
		Note_02.color = Color.grey;
		Note_03.color = Color.grey;
		Note_04.color = Color.grey;
	}
}