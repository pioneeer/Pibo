﻿using UnityEngine;
using System.Collections;

public class Btn_Play : MonoBehaviour {
	private Global_Var Glo;
	public UnityEngine.UI.Text Text_Error_List;
	
	void Start () {
		Glo = GameObject.Find ("Global").GetComponent <Global_Var>();
	}

	public void BtnRestart () {
	if(Glo.Note_Total > 0)
	{
		//Application.LoadLevel("03_Music_Play"); 
		if( !System.IO.File.Exists(Glo.Path_Now_Playing) )	System.IO.File.Create (Glo.Path_Now_Playing).Dispose();
		
		System.IO.StreamWriter sw;
		sw = new System.IO.StreamWriter (Glo.Path_Now_Playing);
		sw.Flush();
		sw.WriteLine(Glo.Path_Note_Now);
		sw.WriteLine(""+Glo.Play_Speed_Mul);
		sw.WriteLine(""+Glo.Note_Speed_Mul);
		sw.Close();
		
		AndroidJavaClass jc = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
		AndroidJavaObject jo = jc.GetStatic<AndroidJavaObject>("currentActivity");
		AndroidJavaObject pm = jo.Call<AndroidJavaObject>("getPackageManager");
		AndroidJavaObject intent = pm.Call<AndroidJavaObject>("getLaunchIntentForPackage", "com.Piano.play");
		jo.Call("startActivity", intent); 
	}
	
	else
	{
		Text_Error_List.text = "재생할 악보가 없습니다.";
		Text_Error_List.SendMessage("Error_Occured");
	}
	}
}