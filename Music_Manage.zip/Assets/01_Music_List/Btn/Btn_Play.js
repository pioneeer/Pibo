﻿#pragma strict

var Glo : Global_Var;
var Text_Error_List : UI.Text;

function Start () {
	Glo = GameObject.Find("Global").GetComponent("Global_Var");
}

function BtnRestart () {
	if(Glo.Note_Total > 0)
	{
		if( !System.IO.File.Exists(Glo.Path_Now_Playing) )	System.IO.File.Create (Glo.Path_Now_Playing);
		
		var sw : System.IO.StreamWriter;
		sw = new System.IO.StreamWriter (Glo.Path_Now_Playing);
		sw.Flush();
		sw.WriteLine(Glo.Path_Note_Now);
		sw.WriteLine(""+Glo.Play_Speed_Mul);
		sw.WriteLine(""+Glo.Note_Speed_Mul);
		sw.Close();
			
		Application.LoadLevel("03_Music_Play");
	}
	else
	{
		Text_Error_List.text = "재생할 악보가 없습니다.";
		Text_Error_List.SendMessage("Error_Occured");
	}
}