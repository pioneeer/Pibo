﻿#pragma strict

var Glo : Global_Var;
var Curs : Cursor_Ctrl;

var Btn_Note_01_Text : UI.Text;
var Btn_Note_02_Text : UI.Text;
var Btn_Note_03_Text : UI.Text;
var Btn_Note_04_Text : UI.Text;

private var Note_Now	: int;
private var Note_Total 	: int;

private var Note_No : String[] = new String[4];

function Start () {	
	Glo = GameObject.Find("Global").GetComponent("Global_Var");
	Curs = GameObject.Find("Cursor_Ctrl").GetComponent("Cursor_Ctrl");
	
	Glo.Note_Now = 1;
	Curs.Cursor_pos = 1;
	
	Note_Now = -1;
	Note_Total = -1;
}

function Update () {

	var i : int;
	
	if( Note_Now != Glo.Note_Now || Note_Total != Glo.Note_Total)
	{
		if (Glo.Note_Total >= 4)
		{
			if(Curs.Cursor_pos == 0)	
			{
				Note_No[0] = "" + (Glo.Note_Now + 0) + ". " + Glo.Note[Glo.Note_Now - 1 ];
				Note_No[1] = "" + (Glo.Note_Now + 1) + ". " + Glo.Note[Glo.Note_Now + 0 ];
				Note_No[2] = "" + (Glo.Note_Now + 2) + ". " + Glo.Note[Glo.Note_Now + 1 ];
				Note_No[3] = "" + (Glo.Note_Now + 3) + ". " + Glo.Note[Glo.Note_Now + 2 ];	
				
				Curs.Cursor_pos++;
			}
			
			else if (Curs.Cursor_pos == 5)
			{
				Note_No[0] = "" + (Glo.Note_Now - 3) + ". " + Glo.Note[Glo.Note_Now - 4];
				Note_No[1] = "" + (Glo.Note_Now - 2) + ". " + Glo.Note[Glo.Note_Now - 3];
				Note_No[2] = "" + (Glo.Note_Now - 1) + ". " + Glo.Note[Glo.Note_Now - 2];
				Note_No[3] = "" + (Glo.Note_Now + 0) + ". " + Glo.Note[Glo.Note_Now - 1];	
				
				Curs.Cursor_pos--;
			}
			
			else
			{
				if(Glo.Note_Now > Glo.Note_Total)
				{
					Glo.Note_Now = Glo.Note_Total;
					Note_No[0] = "" + (Glo.Note_Now - 3) + ". " + Glo.Note[Glo.Note_Now - 4];
					Note_No[1] = "" + (Glo.Note_Now - 2) + ". " + Glo.Note[Glo.Note_Now - 3];
					Note_No[2] = "" + (Glo.Note_Now - 1) + ". " + Glo.Note[Glo.Note_Now - 2];
					Note_No[3] = "" + (Glo.Note_Now + 0) + ". " + Glo.Note[Glo.Note_Now - 1];
				}
				
				else if(Glo.Note_Now + 4 - Curs.Cursor_pos > Glo.Note_Total)
				{
					for(i=Curs.Cursor_pos; i>0; i--)
					{
						Note_No[i-1] = "" + (Glo.Note_Now - Curs.Cursor_pos + i - 1) + ". " + Glo.Note[Glo.Note_Now - Curs.Cursor_pos + i -2];
					}
					for(i=Curs.Cursor_pos; i<4; i++)
					{
						Note_No[i] = "" + (Glo.Note_Now - Curs.Cursor_pos + i + 1) + ". " + Glo.Note[Glo.Note_Now - Curs.Cursor_pos + i -1];
					}
					Glo.Note_Now--;
				}
				
				else
				{
					for(i=Curs.Cursor_pos-1; i<4; i++)
					{
						if(Glo.Note_Now + i - Curs.Cursor_pos +1 <= Glo.Note_Total) Note_No[i] = "" + (Glo.Note_Now + i -Curs.Cursor_pos +1) + ". " + Glo.Note[Glo.Note_Now + i -Curs.Cursor_pos];
					}
				}
			}
		}
		
		else
		{
			for(i=0; i<4; i++)
			{
				if (Glo.Note_Total > i)
				{
					Note_No[i] = "" + (i+1) + ". " + Glo.Note[i];
				}
			}
		}
		if ( Glo.Note_Total > 0)	Btn_Note_01_Text.text = Note_No[0];
		else						Btn_Note_01_Text.text = " - -   No File   - -";
		if ( Glo.Note_Total > 1)	Btn_Note_02_Text.text = Note_No[1];
		else						Btn_Note_02_Text.text = " - -   No File   - -";
		if ( Glo.Note_Total > 2)	Btn_Note_03_Text.text = Note_No[2];
		else						Btn_Note_03_Text.text = " - -   No File   - -";
		if ( Glo.Note_Total > 3)	Btn_Note_04_Text.text = Note_No[3];
		else						Btn_Note_04_Text.text = " - -   No File   - -";
		
		if ( Glo.Note_Total > 0) 	Glo.Path_Note_Now = Glo.Path_Directory + "/" + Glo.Note[ Glo.Note_Now -1 ] + ".txt";
		
		Note_Now = Glo.Note_Now;
		Note_Total = Glo.Note_Total;
	}
}