﻿#pragma strict

var Curs : Cursor_Ctrl;

function Start () {
	Curs = GameObject.Find("Cursor_Ctrl").GetComponent("Cursor_Ctrl");
}

function BtnRestart () {
    Curs.Move_Down();
}