﻿#pragma strict

function BtnRestart () {
	Application.LoadLevel("02_Music_Add") ;
}