﻿#pragma strict

var Glo : Global_Var;
var Curs : Cursor_Ctrl;

var Btn_Note : UI.Button;

private var Btn_No : int;

function Start () {
	Glo = GameObject.Find("Global").GetComponent("Global_Var");
	Curs = GameObject.Find("Cursor_Ctrl").GetComponent("Cursor_Ctrl");
	
	if		(Btn_Note.gameObject.name == "Btn_Note_01")	Btn_No = 1;
	else if (Btn_Note.gameObject.name == "Btn_Note_02")	Btn_No = 2;
	else if (Btn_Note.gameObject.name == "Btn_Note_03")	Btn_No = 3;
	else if (Btn_Note.gameObject.name == "Btn_Note_04")	Btn_No = 4;
}

function BtnRestart () {
	if( Glo.Note_Now - (Curs.Cursor_pos - Btn_No) <= Glo.Note_Total)
	{
		Glo.Note_Now -= (Curs.Cursor_pos - Btn_No);
		Curs.Cursor_pos = Btn_No;
	}
}