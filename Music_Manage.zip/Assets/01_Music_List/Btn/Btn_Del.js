﻿#pragma strict

var Glo : Global_Var;
var Curs : Cursor_Ctrl;
var Text_Error_List : UI.Text;

function Start () {	
	Glo = GameObject.Find("Global").GetComponent("Global_Var");
}

function BtnRestart () {
	var i : int;
	
	if(Glo.Note_Total > 0)
	{
		Index_Del(Glo.Path_Index, Glo.Path_Index_Copy, Glo.Note[Glo.Note_Now-1]);
		
		Glo.Note[Glo.Note_Now-1] = "";
		for(i=Glo.Note_Now-1; i<Glo.Note_Total; i++)
		{
			Glo.Note[i] = Glo.Note[i+1];
		}
		//if(Glo.Note_Now == Glo.Note_Total)	Glo.Note_Now--;
		Glo.Note[--Glo.Note_Total] = "";
	}
	
	else
	{
		Text_Error_List.text = "삭제할 악보가 없습니다.";
		Text_Error_List.SendMessage("Error_Occured");
	}
}

function Index_Del (Original_File : String, Copy_File : String, String_to_Del: String) 
{ 
	var sr : System.IO.StreamReader;
	var sw : System.IO.StreamWriter;
	
	sr = new System.IO.File.OpenText (Copy_File);
	sw = new System.IO.StreamWriter (Original_File);
	
	var input : String;
	input = "";
	
	sw.Flush();
	while (true)
	{ 
		input = sr.ReadLine(); 
		if (input == null)	 break; 
		
		else
		{
			if (input != String_to_Del)
			{
				sw.WriteLine(input);
			}
		}
	}
	
	sr.Close();
	sw.Close();
	
	sr = new System.IO.File.OpenText (Original_File);
	sw = new System.IO.StreamWriter (Copy_File);
	input = "";
	
	sw.Flush();
	while (true)
	{ 
		input = sr.ReadLine(); 
		if (input == null)	 break; 
		
		sw.WriteLine(input);
	}
	
	sr.Close();
	sw.Close();
	
	System.IO.File.Delete(Glo.Path_Directory + "/" + String_to_Del + ".txt");
	System.IO.File.Delete(Glo.Path_Directory + "/" + String_to_Del + ".jpg");
}