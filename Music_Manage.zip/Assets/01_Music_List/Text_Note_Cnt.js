﻿#pragma strict

var Text_Note_Cnt : UI.Text;

var Glo : Global_Var;

function Start () {
	Glo = GameObject.Find("Global").GetComponent("Global_Var");
	
	Text_Note_Cnt.text = "Note No.\n" + Glo.Note_Now;
	Text_Note_Cnt.text += " / " + Glo.Note_Total;
}

function Update () {
	Text_Note_Cnt.text = "Total No.\n" + Glo.Note_Now;
	Text_Note_Cnt.text += " / " + Glo.Note_Total;
}