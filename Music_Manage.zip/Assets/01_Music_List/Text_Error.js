﻿#pragma strict

var Text_Error : UI.Text;
var Panel : UI.Image;

private var On : boolean;
private var Timer : float ;

function Start () {
	On = false;
	Timer = 0;
	Text_Error.color = Color(1,0,0,0);
	Panel.color = Color(1,0,0,0);
}

function Update () {
	var Cooltime : int = 2;
	
	if (On) {
		Timer += Time.deltaTime;
		if (Timer < 1) {
			Text_Error.color = Color(1,0,0,1);
			Panel.color = Color(1,0,0,0.5);
		}
		else {
			Text_Error.color = Color(1,0,0,2-Timer);
			Panel.color = Color(1,0,0,1-Timer/2);
		}
		if( Timer > 2) {
			On = false;
			Timer = 0;
		}
	}
}

function Error_Occured () {
	On = true;
	Timer = 0;
}