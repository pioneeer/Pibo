﻿#pragma strict

var Select_Cursor : GameObject;

private var MoveCoolTime : float;
private var Timer : float;
private var check : boolean;

private var Gap : int;
private var Cursor_pos_Low : int;
private var Cursor_pos_High : int;

private static var Accel_Init_Value_x : float;
private static var Accel_Init_Value_y : float;
private static var Accel_Init_Value_z : float;
public var Cursor_pos : int;

var Glo : Global_Var;

function Start () {

	Glo = GameObject.Find("Global").GetComponent("Global_Var");

	MoveCoolTime = 0.2;
	Timer = 0;
	check = true;
	
	Gap = 100;
	
	Cursor_pos = 1;
	
	Cursor_pos_High = 570;
	Cursor_pos_Low = 570 - Gap*3;
	
	Select_Cursor.transform.position.y = Cursor_pos_High;
	
	Accel_Init_Value_x = Input.acceleration.x;
	Accel_Init_Value_y = Input.acceleration.y;
	Accel_Init_Value_z = Input.acceleration.z;
}

function Update () {

	if ( Cursor_pos > Glo.Note_Total )
	{
		Cursor_pos = Glo.Note_Total;
		Glo.Note_Now = Glo.Note_Total;
		Select_Cursor.transform.position.y = Cursor_pos_High - ( (Cursor_pos-1) * Gap);
	}
	
	if(check == false) {
		Timer += Time.deltaTime;
		
		if (Timer >= MoveCoolTime)	check = true;
	}
	
	if(check == true)	Move_by_key();
	
	if( Cursor_pos == 0)		Select_Cursor.transform.position.y = Cursor_pos_High;
	else if( Cursor_pos == 5)	Select_Cursor.transform.position.y = Cursor_pos_Low;
	else						Select_Cursor.transform.position.y = Cursor_pos_High - ( (Cursor_pos-1) * Gap);
	
	if( Glo.Note_Total == 0)	Select_Cursor.transform.position.y = 1000;
	
	
	if( Accel_Init_Value_x == 0 && Accel_Init_Value_y == 0 && Accel_Init_Value_z == 0)
	{
		Accel_Init_Value_x = Input.acceleration.x;
		Accel_Init_Value_y = Input.acceleration.y;
		Accel_Init_Value_z = Input.acceleration.z;
	}
}

function Move_by_key () {
	if ( Input.GetKey("up") )			Move_Up();
	else if ( Input.GetKey("down") )	Move_Down();
}

function Move_by_gyro () {
	if		(Accel_Init_Value_z - Input.acceleration.z > 0.4)	Move_Down();
	else if	(Accel_Init_Value_z - Input.acceleration.z < -0.4)	Move_Up();
	else if	(Accel_Init_Value_x - Input.acceleration.x < -0.08)	Application.LoadLevel("Main");
	//else if	(Accel_Init_Value_x - Input.acceleration.x > 0.08)	Text_Accel.text += "\n\nRIGHT";
}

function Move_Up ()
{
	if  (Glo.Note_Now > 1 )
	{
		Glo.Note_Now--;
		Cursor_pos--;
		
		check = false;
		Timer = 0;
	}
}

function Move_Up_x5 ()
{
	if  (Glo.Note_Now > 1 )
	{
		if (Glo.Note_Now > 4 ) Glo.Note_Now -= 4;
		else Glo.Note_Now = 1;
		Cursor_pos = 1;
		
		check = false;
		Timer = 0;
	}
}

function Move_Down ()
{
	if  ( Glo.Note_Now < Glo.Note_Total )
	{
		Glo.Note_Now++;
		Cursor_pos++;
		
		check = false;
		Timer = 0;
	}
}

function Move_Down_x5 ()
{
	if  ( Glo.Note_Now < Glo.Note_Total )
	{
		if (Glo.Note_Total - Glo.Note_Now > 4 ) Glo.Note_Now += 4;
		else Glo.Note_Now = Glo.Note_Total;
		Cursor_pos = 5;
		
		check = false;
		Timer = 0;
	}
}