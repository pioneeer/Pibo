﻿#pragma strict

function Start () {
	Screen.SetResolution(1280, 720, true);
}

function Update () {

}