package com.example.pibo_dbg;

import android.app.Activity;
import android.content.Intent;

public class UnityBinder {
	
	public static void OpenGallery(Activity activity){
		Intent intent = new Intent(activity, MSRecogActivity.class);
		activity.startActivity(intent);
	}
}
