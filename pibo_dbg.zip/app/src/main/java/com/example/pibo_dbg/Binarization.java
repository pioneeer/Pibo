package com.example.pibo_dbg;

import android.graphics.Bitmap;

import org.opencv.android.Utils;
import org.opencv.core.Mat;
import org.opencv.imgproc.Imgproc;

public class Binarization {
	public static Bitmap getBinaryBitmap(Bitmap originbit){
    	Mat binaryMat = new Mat();
    	Bitmap originalBit = originbit;
    	
    	Utils.bitmapToMat(originalBit, binaryMat);
    	
    	Imgproc.cvtColor(binaryMat, binaryMat, Imgproc.COLOR_RGB2GRAY);
    	//Core.normalize(BinaryMat, BinaryMat, 0, 255, Core.NORM_MINMAX, CvType.CV_8U);
    	
    	Imgproc.threshold(binaryMat, binaryMat, 200, 255, Imgproc.THRESH_BINARY);
    	

    	Utils.matToBitmap(binaryMat, originalBit);
    	
    	return originalBit;
    }
}
