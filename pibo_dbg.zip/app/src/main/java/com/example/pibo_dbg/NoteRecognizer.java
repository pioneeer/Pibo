package com.example.pibo_dbg;


import java.util.List;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;

import android.util.Log;

public class NoteRecognizer {

	public static int lineInterval = SectionDevider.getLineInterval();

	public static String str = "";
	
	public static String getStr(){
		return str;
	}
	
	public static void slash(){
		str += "/";
	}
	


	public static void findNote(List<Mat> sectionList){
		int line1 = 0;
		int line2 = 0;
		int line3 = 0;
		int line4 = 0;
		int line5 = 0;
		int line6 = 0;
		int sectionListSize = sectionList.size();
		for(int i = 0;i<sectionListSize;i++){
	
			Mat outputMat = new Mat();
			outputMat = sectionList.get(i);
			


			//����+1 ���� üũ 
			int stch = 0;
			double[] tp;
			tp = outputMat.get(0, 0);

			for(int v=0;v<outputMat.height();v++){
				
				tp = outputMat.get(v, 0);
				
				if(tp[0] <= 20 && tp[1] <= 20 && tp[2] <= 20 && stch == 0){
					if(line1 == 0) line1 = v;
					else if(line2 == 0) line2 = v;
					else if(line3 == 0) line3 = v;
					else if(line4 == 0) line4 = v;
					else if(line5 == 0){
						line5 = v;
						line6 = line5 + lineInterval;
					}
					stch = 1;
				}
				else stch = 0;
			}
			Log.i("6 lines", "6 lines" + line1 + " " + line2 + " " + line3 + " " + line4 + " " +line5 + " " + line6);
			for(int a = outputMat.width()-1;a>=0;a--){
				double[] tale;
				tale = outputMat.get(outputMat.height()/2, a);
				if(tale[0] <= 20 && tale[1] <= 20 && tale[2] <= 20){
					Core.rectangle(outputMat, new Point(a-10, 0), new Point(outputMat.width(), outputMat.height()), new Scalar(255, 255, 255, 255), -1);
					break;
				}
			}
			
			//��ǥ ��ġ ã��.
			for(int a = 0;a<outputMat.width();a++){
				double[] lineTemp;					//
				double[] lineAround;				//
				double[] upDown;					//
				double[] dot;						//
				int dotCount = 0;
				int[] stemRecog = new int[4];		//��ǥ �ֺ� �˻�.
				int lCount = 0;						//
				int blackCount = 0;					//
				boolean isBlack = false;			//
				boolean isStem = false;				//���� cols�� ��ǥ���� �ƴ��� ����.
				int lStart = 0;						//��ǥ �ٱ��� ó�� �κ�.
				int lEnd = 0;						//��ǥ �ٱ��� �� �κ�.
				double time = 0; 					//����.
				double howLong = 1.0;				//���� ����.
				for(int b = 0;b<outputMat.height();b++){
					lineTemp = outputMat.get(b, a);
					if(lineTemp != null){
						if(lineTemp[0] <= 20 && lineTemp[1] <= 20 && lineTemp[2] <= 20){
							lCount++;
							isStem = true;
							if(lStart == 0) lStart = b;
						}else if(isStem == true && lCount < lineInterval*5/2){
							isStem = false;
							lCount = 0;
							lStart = 0;
						}else if(lCount >= lineInterval*5/2 && lineTemp[0] >= 20 && lineTemp[1] >= 20 && lineTemp[2] >= 20)
							break;
					}
				}
				lEnd = lStart + lCount;
				
				//Core.line(outputMat, new Point(a-4, lStart), new Point(a+4, lStart), new Scalar(255, 0, 0, 255));
				//Core.line(outputMat, new Point(a-4, lEnd), new Point(a+4, lEnd), new Scalar(255, 0, 0, 255));
				
				if(lCount >= lineInterval*5/2){
					//1
					for(int c = 0;c<lineInterval*1.5;c++){
						//Core.line(outputMat, new Point(a-lineInterval/2+2, lStart), new Point(a-lineInterval/2+2, lStart+lineInterval*1.5), new Scalar(255, 0, 0, 255));
						lineAround = outputMat.get(c+lStart, a-lineInterval/2+2);
						if(lineAround != null){
							if(lineAround[0] <= 20 && lineAround[1] <= 20 && lineAround[2] <= 20 && isBlack == false){
								isBlack = true;
								blackCount++;
							}else if(lineAround[0] > 20 && lineAround[1] > 20 && lineAround[2] > 20)
								isBlack = false;
						}
					}
					stemRecog[0] = blackCount;
					blackCount = 0;
					isBlack = false;
					
					
					//2
					for(int c = 0;c<lineInterval*1.5;c++){
						//Core.line(outputMat, new Point(a+lineInterval/2-2, lStart+2), new Point(a+lineInterval/2-2, lStart+lineInterval*1.5+2), new Scalar(255, 0, 0, 255));
						lineAround = outputMat.get(c+lStart, a+lineInterval/2-2);
						if(lineAround != null){
							if(lineAround[0] <= 20 && lineAround[1] <= 20 && lineAround[2] <= 20 && isBlack == false){
								isBlack = true;
								blackCount++;
							}else if(lineAround[0] > 20 && lineAround[1] > 20 && lineAround[2] > 20)
								isBlack = false;
						}
					}
					stemRecog[1] = blackCount;
					blackCount = 0;
					isBlack = false;
					
					
					//3
					for(int c = 0;c<lineInterval*1.5;c++){
						//Core.line(outputMat, new Point(a-lineInterval/2+2, lEnd-lineInterval), new Point(a-lineInterval/2+2, lEnd+lineInterval/2), new Scalar(255, 0, 0, 255));
						lineAround = outputMat.get(c+lEnd-lineInterval, a-lineInterval/2+2);
						if(lineAround != null){
							if(lineAround[0] <= 20 && lineAround[1] <= 20 && lineAround[2] <= 20 && isBlack == false){
								isBlack = true;
								blackCount++;
							}else if(lineAround[0] > 20 && lineAround[1] > 20 && lineAround[2] > 20)
								isBlack = false;
						}
						
					}
					stemRecog[2] = blackCount;
					blackCount = 0;
					isBlack = false;
					
					
					//4
					for(int c = 0;c<lineInterval;c++){
						//Core.line(outputMat, new Point(a+lineInterval/2-2, lEnd-lineInterval), new Point(a+lineInterval/2-2, lEnd+lineInterval/2), new Scalar(255, 0, 0, 255));
						lineAround = outputMat.get(c+lEnd-lineInterval, a+lineInterval/2-2);
						if(lineAround != null){
							if(lineAround[0] <= 20 && lineAround[1] <= 20 && lineAround[2] <= 20 && isBlack == false){
								isBlack = true;
								blackCount++;
							}else if(lineAround[0] > 20 && lineAround[1] > 20 && lineAround[2] > 20)
								isBlack = false;
						}
						
					}
					stemRecog[3] = blackCount;
					blackCount = 0;
					isBlack = false;
					
					
					
					//���� ã��.
					int highSproutCount = 0;
					int lowSproutCount = 0;
					for(int d = 1;d<lineInterval;d++){//w
						for(int e = 0;e<lineInterval;e++){//h
							upDown = outputMat.get(e+lStart-lineInterval/2, d+a);
							if(upDown != null){
								if(upDown[0] <= 20 && upDown[1] <= 20 && upDown[2] <= 20)
									highSproutCount++;
							}
						}
					}
					for(int d = -1;d<lineInterval;d++){//w
						for(int e = 0;e<lineInterval;e++){//h
							upDown = outputMat.get(e+lEnd-lineInterval/2, d+a-lineInterval);
							if(upDown != null){
								if(upDown[0] <= 20 && upDown[1] <= 20 && upDown[2] <= 20)
									lowSproutCount++;
							}
						}
					}
					Log.i("SproutCount", "SproutCount" + lowSproutCount + " " + highSproutCount);
					
					//�ᳪ�� ��, �Ʒ� pixel �˻��ϴ� �κ�.
					//Core.rectangle(outputMat, new Point(1+a, lStart-lineInterval/2), new Point(1+a+lineInterval, lStart+lineInterval/2), new Scalar(255, 0, 0, 255));
					//Core.rectangle(outputMat, new Point(-1+a-lineInterval, lEnd-lineInterval/2), new Point(-1+a, lEnd+lineInterval/2), new Scalar(255, 0, 0, 255));
					
					//��ǥ �� �� ���.
					if(highSproutCount > lowSproutCount && Math.abs(highSproutCount-lowSproutCount) > lineInterval){
						for(int f = a+lineInterval*4/3;f<a+lineInterval*5/3;f++){
							for(int g = lStart-lineInterval/2;g<lStart;g++){
								try{
									dot = outputMat.get(g, f);
									if(dot[0] <= 20 && dot[1] <= 20 && dot[2] <= 20){
										dotCount++;
									}
								}catch(ArrayIndexOutOfBoundsException e1){
								}catch(NullPointerException e2){
								}
							}
						}
						//3���� ���� ������ ������ �ػ󵵸��� �޶��� �� ����.
						Log.i("xxxx", "xxxx" + dotCount);
						if(dotCount >= 1) 
							howLong = 1.5;
						//Core.rectangle(outputMat, new Point(a+lineInterval*4/3, lStart-lineInterval/2), new Point(a+lineInterval*5/3, lStart), new Scalar(255, 0, 0, 255));
					}else if(highSproutCount < lowSproutCount && Math.abs(highSproutCount-lowSproutCount) > lineInterval){
						for(int f = a+lineInterval/3;f<a+lineInterval*2/3;f++){
							for(int g = lEnd-lineInterval/2;g<lEnd;g++){
								
								try{
									dot = outputMat.get(g, f);
									if(dot[0] <= 20 && dot[1] <= 20 && dot[2] <= 20){
										dotCount++;
									}
								}catch(ArrayIndexOutOfBoundsException e1){
								}catch(NullPointerException e2){
								}
								
							}
						}
						//3���� ���� ������ ������ �ػ󵵸��� �޶��� �� ����.
						Log.i("xxxx", "xxxx" + dotCount);
						if(dotCount >= 1) 
							howLong = 1.5;
						
						//Core.rectangle(outputMat, new Point(a+lineInterval/3, lEnd-lineInterval/2), new Point(a+lineInterval*2/3, lEnd), new Scalar(255, 0, 0, 255));
					};
					
					dotCount = 0;
					
					
					
					int line05 = line1 - lineInterval/2;
					int line15 = line1 + lineInterval/2;
					int line25 = line2 + lineInterval/2;
					int line35 = line3 + lineInterval/2;
					int line45 = line4 + lineInterval/2;
					int line55 = line5 + lineInterval/2;
					Log.i("6 lines", "6 lines" + line05 + " " + line15 + " " + line25 + " " + line35 + " " +line45 + " " + line55);

					int lSo = Math.abs(line05-lStart);
					int lPa = Math.abs(line1-lStart);
					int lMi = Math.abs(line15-lStart);
					int lRe = Math.abs(line2-lStart);
					int lDo = Math.abs(line25-lStart);
					int lSi = Math.abs(line3-lStart);
					
					int hRa = Math.abs(line35-lEnd+1);
					int hSo = Math.abs(line4-lEnd+1);
					int hPa = Math.abs(line45-lEnd+1);
					int hMi = Math.abs(line5-lEnd+1);
					int hRe = Math.abs(line55-lEnd+1);
					int hDo = Math.abs(line6-lEnd+1);

					int close = 0;
					if(highSproutCount > lowSproutCount && Math.abs(highSproutCount-lowSproutCount) > lineInterval){
						//���� �ᳪ���� �޸� ���
						close = Math.min(lSo, lPa);
						close = Math.min(close, lMi);
						close = Math.min(close, lRe);
						close = Math.min(close, lDo);
						close = Math.min(close, lSi);
						if(close == lSo){ 
							str+="25";
							Log.i("Node1", "Node1" + "h��");
						}
						else if(close == lPa){ 
							str+="24";
							Log.i("Node1", "Node1" + "h��");
						}
						else if(close == lMi){ 
							str+="23";
							Log.i("Node1", "Node1" + "h��");
						}
						else if(close == lRe){ 
							str+="22";
							Log.i("Node1", "Node1" + "h��");
						}
						else if(close == lDo){ 
							str+="21";
							Log.i("Node1", "Node1" + "h��");
						}
						else if(close == lSi){ 
							str+="20";
							Log.i("Node1", "Node1" + "h��");
						}
						////////////////////////////////////////////////////////////////////////////////////////////////
					}else if(highSproutCount < lowSproutCount && Math.abs(highSproutCount-lowSproutCount) > lineInterval){
						//�Ʒ��� �ᳪ���� �޸� ���
						close = Math.min(hDo, hRe);  	
						close = Math.min(close, hMi);
						close = Math.min(close, hPa);
						close = Math.min(close, hSo);
						close = Math.min(close, hRa);
						if(close == hDo){
							str+="14";
							Log.i("Node1", "Node1" + "l��");
						}
						else if(close == hRe){
							str+="15";
							Log.i("Node1", "Node1" + "l��");
						}
						else if(close == hMi){
							str+="16";
							Log.i("Node1", "Node1" + "l��");
						}
						else if(close == hPa){
							str+="17";
							Log.i("Node1", "Node1" + "l��");
						}
						else if(close == hSo){
							str+="18";
							Log.i("Node1", "Node1" + "l��");
						}
						else if(close == hRa){
							str+="19";
							Log.i("Node1", "Node1" + "l��");
						}
					}
					
					
					
					
					if(stemRecog[0] == 0 && stemRecog[1] == 0 && stemRecog[2] == 1 && stemRecog[3] == 0){//0010
						time = 1*howLong;
						if(howLong == 1) str+="4"; else if(howLong == 1.5) str+="3";
						Log.i("Node", "Node" + time + "����");
					}else if(stemRecog[0] == 0 && stemRecog[1] == 1 && stemRecog[2] == 0 && stemRecog[3] == 0){//0100
						time = 1*howLong;
						if(howLong == 1) str+="4"; else if(howLong == 1.5) str+="3";
						Log.i("Node", "Node" + time + "����");
					}
					
					///
					else if(stemRecog[0] == 0 && stemRecog[1] == 0 && stemRecog[2] == 1 && stemRecog[3] == 1){//0011
						time = 1*howLong;
						str+="3";
						Log.i("Node", "Node" + time + "����");
					}
					
					else if(stemRecog[0] == 0 && stemRecog[1] == 0 && stemRecog[2] >= 2 && stemRecog[3] == 0){//0020
						time = 2*howLong;
						if(howLong == 1) str+="2"; else if(howLong == 1.5) str+="1";
						Log.i("Node", "Node" + time + "����");
					}else if(stemRecog[0] == 0 && stemRecog[1] >= 2 && stemRecog[2] == 0 && stemRecog[3] == 0){//0200
						time = 2*howLong;
						if(howLong == 1) str+="2"; else if(howLong == 1.5) str+="1";
						Log.i("Node", "Node" + time + "����");
					}else if(stemRecog[0] == 0 && stemRecog[1] == 0 && stemRecog[2] >= 2 && stemRecog[3] == 1){//0021
						time = 2*howLong;
						str+="1";
						Log.i("Node", "Node" + time + "����");
					}
					
					/*else if(stemRecog[0] == 0 && stemRecog[1] == 0 && stemRecog[2] >= 2 && stemRecog[3] == 1){//0021
						Log.i("Node", "Node" + "3����");
					}//3���� �Ųٷ� �������.
*/					
					else if(stemRecog[0] == 0 && stemRecog[1] == 1 && stemRecog[2] == 1 && stemRecog[3] == 0){//0110
						time = 0.5*howLong;
						if(howLong == 1) str+="6"; else if(howLong == 1.5) str+="5";
						Log.i("Node", "Node" + time + "����");
					}else if(stemRecog[0] == 0 && stemRecog[1] == 1 && stemRecog[2] == 0 && stemRecog[3] == 1){//0101
						time = 0.5*howLong;
						if(howLong == 1) str+="6"; else if(howLong == 1.5) str+="5";
						Log.i("Node", "Node" + time + "����");
					}else if(stemRecog[0] == 1 && stemRecog[1] == 0 && stemRecog[2] == 1 && stemRecog[3] == 0){//1010
						time = 0.5*howLong;
						if(howLong == 1) str+="6"; else if(howLong == 1.5) str+="5";
						Log.i("Node", "Node" + time + "����");
					}else if(stemRecog[0] == 1 && stemRecog[1] == 1 && stemRecog[2] == 1 && stemRecog[3] == 0){//1110
						time = 0.5*howLong;
						if(howLong == 1) str+="6"; else if(howLong == 1.5) str+="5";
						Log.i("Node", "Node" + time + "����");
					}else if(stemRecog[0] == 0 && stemRecog[1] == 1 && stemRecog[2] == 1 && stemRecog[3] == 1){//0111
						time = 0.5*howLong;
						str+="5";
						Log.i("Node", "Node" + time + "����");
					}
					
					else if(stemRecog[0] == 0 && stemRecog[1] >= 2 && stemRecog[2] == 1 && stemRecog[3] == 0){//0210
						time = 0.25*howLong;
						str+="7";
						Log.i("Node", "Node" + time + "����");
					}else if(stemRecog[0] == 0 && stemRecog[1] == 1 && stemRecog[2] == 0 && stemRecog[3] >= 2){//0102
						time = 0.25*howLong;
						str+="7";
						Log.i("Node", "Node" + time + "����");
					}else if(stemRecog[0] == 0 && stemRecog[1] == 1 && stemRecog[2] >= 2 && stemRecog[3] == 0){//0120
						time = 0.25*howLong;
						str+="7";
						Log.i("Node", "Node" + time + "����");
					}else if(stemRecog[0] >= 2 && stemRecog[1] == 0 && stemRecog[2] == 1 && stemRecog[3] == 0){//2010
						time = 0.25*howLong;
						str+="7";
						Log.i("Node", "Node" + time + "����");
					}else if(stemRecog[0] >= 2 && stemRecog[1] >= 1 && stemRecog[2] == 1 && stemRecog[3] == 0){//2110
						time = 0.25*howLong;
						str+="6";//���� �� ������
						Log.i("Node", "Node" + time + "����");
					}else if(stemRecog[0] >= 1 && stemRecog[1] >= 2 && stemRecog[2] == 1 && stemRecog[3] == 0){//1210
						time = 0.25*howLong;
						str+="7";
						Log.i("Node", "Node" + time + "����");
					}
					
					
					
					
					else if(stemRecog[0] == 0 && stemRecog[1] == 0 && stemRecog[2] == 0 && stemRecog[3] == 0){//0000
						Log.i("Node", "Node" + "�ѤѤѤѤ�");
					}
					
					else {
						Log.i("Node", "Node" + "�ν� �Ұ�");
					}
					
					
					Log.i("node", "node" + stemRecog[0] + " " + stemRecog[1] + " " + stemRecog[2] + " " + stemRecog[3]);
					
					//�ϳ� ã������ �������� �������� �Ѿ��!
					str+=",";
					a+=lineInterval;
				}
			}
			str = str.substring(0, str.length()-1);
			slash();
		}	
		str+="end";
	}
}
