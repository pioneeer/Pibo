package com.example.pibo_dbg;

import android.graphics.Bitmap;
import android.util.Log;

import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;

import java.util.ArrayList;
import java.util.List;

public class SectionDevider {
	
	public static double coordinates4[];
	public static double coordinates5[];
	public static double coordinates6[];
		
	public static int lineInterval; 			//���� ����.

	public static int getLineInterval(){
		return lineInterval;
	}
	
	public static List<Mat> getSectionList(Bitmap originBit){
    	
    	List<Mat> outputList = new ArrayList<Mat>();
    	Mat outputMat = new Mat();
    	Mat originalMat = new Mat();
    	double[] coordinates1;
    	double[] coordinates2;
    	
    	Utils.bitmapToMat(originBit, originalMat);
    	
    	int benchmark = originalMat.width()/4;		//�˻� �����ϴ� ������.
    	int checkPoint = benchmark*3;				//�˻� ��ġ�� ������.			
    	int lineIntervalTemp = 0;			
    	int lineCounter = 0;						//���� ����.
    	int everyFirst = 0;							//������ �� �κ�.
    	int everyFifth = 0;							//������ �Ʒ� �κ�.
    	int currentLineY = -2;						//���� ���� ���.
    	Boolean isLine = true;

    	//y���� �������鼭 �˻��Ѵ�. 
    	for(int i=0;i<originalMat.height();i++){
			coordinates1 = originalMat.get(i, benchmark);
			
			//�������� ã�� �� ���� y���� �����´�.
			if(coordinates1[0] <= 20 && coordinates1[1] <= 20 && coordinates1[2] <= 20){
				
				int Count = 0;	
				//�������� �˻�.
				for(int j=benchmark;j<checkPoint;j++){
					
					coordinates2 = originalMat.get(i, j);
					
					if(!(coordinates2[0] <= 20 && coordinates2[1] <= 20 && coordinates2[2] <= 20)) break;
					Count++;
					
				}
				//������ ���.
				if(Count > (benchmark*2)-(benchmark/10)){
					
					//������ �� �ϳ� �� 1px������ �������� �ν���.
					if(i == currentLineY+1) isLine = false;
					else isLine = true;
					
					currentLineY = i;
					
					if(isLine == true){
						lineCounter++;	
						Log.i("efef", "efef" + i);
						//���� ������ ���� ����
						Core.line(originalMat, 
								new Point(0, i), 
								new Point(15, i), 
								new Scalar(0, 0, 0, 255));
						
						if(lineIntervalTemp == 0) lineIntervalTemp = i;
						if(lineInterval == 0) lineInterval = i - lineIntervalTemp; 
						if(lineCounter%5 == 1) everyFirst = i;
						if(lineCounter%5 == 0){

							everyFifth = i;
							
							outputMat = originalMat.submat(
									new Rect(
											new Point(10, everyFirst-(lineInterval*2)), 
											new Point(originalMat.width()-10, everyFifth+(lineInterval*2))));							
							//���� �����.
							int startPoint = outputMat.width()/8;
							int sumOfDot = outputMat.width()/5;

							
							for(int q = 0;q<outputMat.height();q++){
								coordinates4 = outputMat.get(q, startPoint);
								int Count2 = 0;
								if(coordinates4[0] <= 20 && coordinates4[1] <= 20 && coordinates4[2] <= 20){
									for(int w = startPoint;w<outputMat.width()-1;w++){
										
										coordinates5 = outputMat.get(q, w);
										
										if(!(coordinates5[0] <= 20 && coordinates5[1] <= 20 && coordinates5[2] <= 20)) break;
										Count2++;
									}
								}
								if(Count2 >= sumOfDot){
									Core.line(outputMat, new Point(6, q), new Point(outputMat.width()/2, q), new Scalar(248, 252, 248, 255), 1);
									for(int e = 6;e<outputMat.width()/2;e++){
										coordinates6 = outputMat.get(q-1, e);
										if(coordinates6[0] <= 10 && coordinates6[1] <= 10 && coordinates6[2] <= 10){
											Core.line(outputMat, new Point(e, q), new Point(e, q), new Scalar(0, 0, 0, 255));
										}
									}
								}
							}
							
							for(int q = 0;q<outputMat.height();q++){
								coordinates4 = outputMat.get(q, startPoint*7);
								int Count3 = 0;
								if(coordinates4[0] <= 20 && coordinates4[1] <= 20 && coordinates4[2] <= 20){
									for(int w = startPoint*7;w>=0;w--){
										
										coordinates5 = outputMat.get(q, w);
										
										if(!(coordinates5[0] <= 20 && coordinates5[1] <= 20 && coordinates5[2] <= 20)) break;
										Count3++;
									}
								}
								if(Count3 >= sumOfDot){
									Core.line(outputMat, new Point(outputMat.width()/2, q), new Point(outputMat.width(), q), new Scalar(248, 252, 248, 255), 1);
									for(int e = outputMat.width()-1;e>=outputMat.width()/2;e--){
										coordinates6 = outputMat.get(q-1, e);
										if(coordinates6[0] <= 10 && coordinates6[1] <= 10 && coordinates6[2] <= 10){
											Core.line(outputMat, new Point(e, q), new Point(e, q), new Scalar(0, 0, 0, 255));
										}
									}
								}
								
							}
							
							//6��° ���� �����. �������� ���� ������. ������ ������ ��. add�� ����Ǿ�� ��!!
							for(int k=outputMat.height()-2;k>=outputMat.height()-lineInterval*2;k--){
								coordinates4 = outputMat.get(k, 1);
								if(coordinates4[0] <= 20 && coordinates4[1] <= 20 && coordinates4[2] <= 20){
									
									Core.line(outputMat, new Point(0, k+lineInterval-1), new Point(outputMat.width(), k+lineInterval-1), new Scalar(248, 252, 248, 255));
									for(int l = 0;l<outputMat.width();l++){
										coordinates5 = outputMat.get(k+lineInterval-2, l);
										if(coordinates5[0] <= 10 && coordinates5[1] <= 10 && coordinates5[2] <= 10){
											Core.line(outputMat, new Point(l, k+lineInterval-1), new Point(l, k+lineInterval-1), new Scalar(0, 0, 0, 255));
										}
									}
									
									Core.line(outputMat, new Point(0, k+lineInterval), new Point(outputMat.width(), k+lineInterval), new Scalar(248, 252, 248, 255));
									for(int l = 0;l<outputMat.width();l++){
										coordinates5 = outputMat.get(k+lineInterval-1, l);
										if(coordinates5[0] <= 10 && coordinates5[1] <= 10 && coordinates5[2] <= 10){
											Core.line(outputMat, new Point(l, k+lineInterval), new Point(l, k+lineInterval), new Scalar(0, 0, 0, 255));
										}
									}
									
									Core.line(outputMat, new Point(0, k+lineInterval+1), new Point(outputMat.width(), k+lineInterval+1), new Scalar(248, 252, 248, 255));
									for(int l = 0;l<outputMat.width();l++){
										coordinates5 = outputMat.get(k+lineInterval, l);
										if(coordinates5[0] <= 10 && coordinates5[1] <= 10 && coordinates5[2] <= 10){
											Core.line(outputMat, new Point(l, k+lineInterval+1), new Point(l, k+lineInterval+1), new Scalar(0, 0, 0, 255));
										}
									}
									
								}
							}
							
							
							
							outputList.add(outputMat);
						}
					}
				}
			}
    	}
    	

    	return outputList;
    }
}
