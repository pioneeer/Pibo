package com.example.pibo_dbg;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Mat;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


//public class MSRecogActivity extends UnityPlayerActivity{
public class MSRecogActivity extends Activity{

	String msg;
    //���� ��.
    private Bitmap bmp;
    //���� ����ȭ.
    private Bitmap binarizationBit;

    //���� ����.
    private List<Mat> passagesMat;
    private List<Bitmap> passagesBit;
    private Bitmap passage;
    
	private ImageView iv1;
    private ImageView iv2;
    private ImageView iv3;
    private ImageView iv4;
    
    private TextView tv1;
    private String noteNumber;
    int PHOTO_GALLERY = 1;
    
    
    private BaseLoaderCallback loaderCallback = new BaseLoaderCallback(this) {
        @Override
        public void onManagerConnected(int status) {
            if(status == LoaderCallbackInterface.SUCCESS && bmp != null){

                	passagesBit = new ArrayList<Bitmap>();
                	passagesMat = new ArrayList<Mat>();
            		//1. bmp�� ī�ǿ��� ����ȭ.
            		int w = bmp.getWidth();
                	int h = bmp.getHeight();
                	bmp = Bitmap.createScaledBitmap(bmp, 1000, 1000*h/w, false);

                    binarizationBit = Binarization.getBinaryBitmap(bmp.copy(Bitmap.Config.RGB_565, true));
                    
                    //2. �Ǻ� �м�.
                    passagesMat = SectionDevider.getSectionList(binarizationBit);
                    NoteRecognizer.findNote(passagesMat);
                    for(int i = 0;i<passagesMat.size();i++){
                    	passage = Bitmap.createBitmap(passagesMat.get(i).width(), passagesMat.get(i).height(), Bitmap.Config.RGB_565);
                        Utils.matToBitmap(passagesMat.get(i), passage);
                        passagesBit.add(passage);
                    }

                    noteNumber = NoteRecognizer.getStr();
                    Log.i("sssss", "sssss" + noteNumber);
            }
            else{
                    super.onManagerConnected(status);
            }
        }
    };

	@Override
	protected void onActivityResult (int requestCode, int resultCode, Intent data)
	{
		if(resultCode == RESULT_OK && requestCode == PHOTO_GALLERY && data!=null)
		{
			Uri uri = data.getData();
			String[] fileColumn = {MediaStore.Images.Media.DATA};
			Cursor cursor = getContentResolver().query(uri, fileColumn, null, null, null);
			cursor.moveToFirst();
			int columnIndex = cursor.getColumnIndex(fileColumn[0]);
			String photoPath = cursor.getString(columnIndex);
			
			
        	File f = new File(photoPath);
        	bmp = FileResizer.getDecodeFile(f);
        	

			//	close this activity
		}
	}
    
	
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.activity_main);
		
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		startActivityForResult(intent, PHOTO_GALLERY);
		
		
        findViewById(R.id.bt1).setOnClickListener(mClickListener);
        findViewById(R.id.bt2).setOnClickListener(mClickListener);
        findViewById(R.id.bt3).setOnClickListener(mClickListener);
        findViewById(R.id.bt4).setOnClickListener(mClickListener);
        findViewById(R.id.bt5).setOnClickListener(mClickListener);

        iv1 = (ImageView)findViewById(R.id.iv1);  
        iv2 = (ImageView)findViewById(R.id.iv2);  
        iv3 = (ImageView)findViewById(R.id.iv3);  
        iv4 = (ImageView)findViewById(R.id.iv4);  
        tv1 = (TextView)findViewById(R.id.tv1);
        
        
    }
   
    

    Button.OnClickListener mClickListener = new View.OnClickListener() {
        public void onClick(View v) {
        	int id = v.getId();
            if(id == R.id.bt1) {
                iv1.setImageBitmap(bmp);
                iv2.setImageBitmap(null);
                iv3.setImageBitmap(null);
                iv4.setImageBitmap(null);
            }
            if(id == R.id.bt2) {
                //����ȭ �� ����.
                iv1.setImageBitmap(binarizationBit);
                iv2.setImageBitmap(null);
                iv3.setImageBitmap(null);
                iv4.setImageBitmap(null);
            }
            if(id == R.id.bt3){
                	try {
                		iv1.setImageBitmap(passagesBit.get(0));
                    	iv2.setImageBitmap(passagesBit.get(1));
                    	iv3.setImageBitmap(passagesBit.get(2));
                    	iv4.setImageBitmap(passagesBit.get(3));
					} catch (Exception e){}
            }
            if(id == R.id.bt4){
                	//���������� �̹��� ��������.
                	Intent it = new Intent(Intent.ACTION_PICK);
                 	it.setType(MediaStore.Images.Media.CONTENT_TYPE);
                 	it.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                 	
                 	startActivityForResult(it, 100);
            }
            if(id == R.id.bt5){
                    tv1.setText(noteNumber);
                    iv1.setImageBitmap(null);
                    iv2.setImageBitmap(null);
                    iv3.setImageBitmap(null);
                    iv4.setImageBitmap(null);
            }
                	
            
        }
    };
    
    
    
    
    @Override
    public void onPause()
    {
    	if(bmp != null){
    		bmp.recycle();
    		bmp = null;
    	}
    	if(binarizationBit != null){
    		binarizationBit.recycle();
    		binarizationBit = null;
    	}
    	super.onPause();
    }
    @Override
    public void onResume()
    {
        super.onResume();
        OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_2_4_9, this, loaderCallback);
    }
}
